package com.jsx.service;

public interface RequireService {

}
